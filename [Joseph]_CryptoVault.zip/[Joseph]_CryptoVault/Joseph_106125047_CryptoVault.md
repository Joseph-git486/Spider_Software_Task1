# Stage 1

Implemented a Python script that:
1. Encrypts a given file using Caesar cipher.
2. Decrypts a file that was encrypted by Caesar cipher.
3. Cracks an encrypted file without the key using frequency analysis.

Caesar cipher is an ancient encryption method where every alphabet of a message is shifted by a fixed number of places called the 'key'.

It protects the message from being read by others directly.

## Limitations

1. Caesar cipher is trivially breakable. Anyone who knows alphabets and counting can crack it.
2. You won't know if someone has tampered with it already.

## Questions

**1) Why is Caesar trivially breakable?**

Caesar cipher is trivially breakable because there are only 25 possible keys. Even if the attacker tries each key by brute force, he can crack it in minutes.

**2) What property of language makes frequency analysis work?**

If we look at the frequency distribution of letters in English, the letter 'e' appears the most. The letters 't', 'a', 'i', etc. follow subsequently. The encryption is uniform, every 'e' is encrypted into the same letter. So this preserves the structure of English. Naturally, the decrypted version would have high frequencies of these letters. By counting the number of times they appear, we can identify the correct key.

# Stage 2

Added hashing feature to the previous encryption mechanism.

Hashing is a way to detect if someone has already tampered with an encrypted message. It works by generating a hash (in this case a 256-bit number represented as a 64-character hexadecimal string) that is unique and can be generated only from the given message. Even if a small change is made, the hash generated will change completely in an unpredictable manner.

So the sender first creates a hash and then adds it to the message along with the encrypted text. The receiver uses the key to decrypt it and generates the hash. If the hash sent matches the computed hash, the message was not tampered with.

## How it works
1) Hash is one-way, you cannot get the original message from the hash code.
2) Every message text has a unique hash. So two distinct texts generating the same hash is extremely unlikely.

## Limitations
1) Hashing is weak if the encryption is weak. The strength of the hash depends on the strength of the encryption method. If the attacker can decrypt the text, he can modify the text, generate a new hash and put it into the message. No one can detect this.

## Questions
**1) Encryption gives confidentiality. Hashing gives integrity. Why do you need both?**

While confidentiality prevents others from reading your message directly, integrity ensures that nobody has tampered with the message.

1) Encryption without hashing cannot detect modifications made to the file. An attacker might change characters in the encrypted file, and the decrypted output will be gibberish. The actual message is lost.

2) Without encryption, anyone can read your message. Hashing is weak without encryption. An attacker might modify the message, create a new hash and put it into the message text. So tampering cannot be detected.

# Stage 3

Implemented a Python script that:
1. Encrypts a given file using AES-256-CBC along with hashing.
2. Decrypts a file that was encrypted by AES-256-CBC.

Unlike Caesar cipher, AES encryption is not breakable.
It divides the file into 16-byte blocks and scrambles the bytes. Also, since two blocks with similar content would look similar as they are encrypted using the same key, additionally the byte-blocks are XORed with the previous encrypted block and then encrypted using the key. This is called CBC (Cipher Block Chaining).

The key is 256-bit long, derived from a password and salt. This is achieved by PBKDF2.
The user types the password and PBKDF2 processes it with the salt to produce a key.

This makes AES encryption computationally unbreakable (it will take longer than the age of the universe to crack it via brute force).

## Limitations
1. Hashing tells you if the file has been tampered with, but it doesn't protect it against tampering. If tampered, the file cannot be decrypted back to the original text properly.
2. If an incorrect password is entered, unpadding fails and throws error which needs to be handled. The hash check can also indirectly catches this.

## Questions

**1) What goes wrong if the IV is reused?**

Similar content would produce the same encryption and the attacker would learn that the sender is sending the same message again. A fresh random IV generated every time ensures that even identical files produce completely different ciphertext.

**2) What does PBKDF2 add that a plain hash doesn't?**

By iterating the hash function many times, PBKDF2 makes brute force computationally expensive. Additionally, the salt ensures that even two identical passwords produce different keys, preventing attackers from using precomputed tables of common passwords (dictionary attacks).

# Stage 4

Implemented a Python script that:

1. Generates an RSA public-private key pair.
2. Encrypts a file using AES-256-CBC.
3. Encrypts the AES key using the recipient's RSA public key.
4. Decrypts the AES key using the RSA private key.
5. Decrypts the file using the recovered AES key.
6. Verifies file integrity using hashing.

AES is extremely fast and suitable for encrypting large files, but it requires both parties to possess the same secret key. Securely sharing this key over an untrusted network is difficult.

RSA solves this problem using asymmetric cryptography. Each user has two keys:

* A public key that can be shared with anyone.
* A private key that must be kept secret.

Anyone can encrypt data using the public key, but only the holder of the corresponding private key can decrypt it.

Since RSA is computationally expensive, it is not used to encrypt the entire file. Instead, a random AES key is generated and used to encrypt the file. The AES key is then encrypted using RSA. This approach combines the efficiency of AES with the secure key exchange capability of RSA.

This technique is called hybrid encryption and is widely used in modern secure communication systems.

## How it works

1. A random AES-256 key is generated.
2. The file is encrypted using AES-256-CBC.
3. The AES key is encrypted using the recipient's RSA public key.
4. The encrypted AES key and ciphertext are stored together.
5. The recipient uses their RSA private key to recover the AES key.
6. The recovered AES key is used to decrypt the file.
7. Hash verification confirms that the file has not been modified.

## Limitations

1. RSA is much slower than symmetric encryption and is unsuitable for encrypting large files directly.
2. If the private key is stolen, an attacker can decrypt all messages intended for that key pair.
3. RSA provides confidentiality but does not prove who sent the message. A digital signature mechanism is required for authentication and non-repudiation.

## Questions

**1) Why can’t we encrypt the whole file with RSA directly?**

RSA operations are computationally expensive and can only process limited amounts of data at a time. Encrypting large files directly with RSA would be inefficient and impractical. AES is significantly faster and is therefore used for bulk data encryption.

**2) How does this hybrid approach relate to how HTTPS works**

HTTPS uses the same basic hybrid encryption approach. When a client connects to a website, the server presents its public key through a digital certificate. The client generates a random symmetric session key and securely exchanges it using public-key cryptography. Once both parties possess the same session key, they switch to symmetric encryption for the actual data transfer.
