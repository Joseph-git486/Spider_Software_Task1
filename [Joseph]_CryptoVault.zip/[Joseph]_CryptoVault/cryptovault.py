from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes, padding
from cryptography.exceptions import InvalidKey
from cryptography.hazmat.primitives.asymmetric import rsa, padding as rsa_padding
from cryptography.hazmat.primitives import serialization
import os
import argparse
import hashlib
import sys

def caesar(text, shift):
    new_text = ""
    for char in text:
        if char.isalpha():
            if char.islower():
                new_char = chr( ((ord(char)-ord('a')) +shift)%26 + ord('a') )
                new_text += new_char
            elif char.isupper():
                new_char = chr( ((ord(char)- ord('A')) +shift)%26 + ord('A') )
                new_text += new_char
        else:
            new_text += char
    return new_text

def score(text):
    common_letters = ['e', 't', 'a', 'o','i', 'n', 's', 'h', 'r']
    score = 0
    for char in text:
        if char.lower() in common_letters:
            score += 1
    if not text:
        return 0
    return score/len(text)

def crack(text):
    result = []
    for shift in range(0,26):
        new_text = caesar(text,shift)
        result.append([shift,score(new_text)])
    result.sort(key = lambda x: x[1], reverse = True)
    for i in range(3):
        new_text = caesar(text, result[i][0])
        print("match no:", str(i+1))
        print(new_text)
        print("\n\n")

def verify(text, hash):
    computed_hash = hashlib.sha256(text.encode()).hexdigest()
    if not (hash == computed_hash):
        print("Warning: The file has been tampered")
    else:
        print("The file is not tampered.")

def derive_key(password, salt):
    kdf = PBKDF2HMAC(
        algorithm = hashes.SHA256(),
        length = 32,
        salt = salt,
        iterations=100000       # This makes guessing password epensive. Imagine an attacker uses your salt and tries to guess the password to get the key. If PBKDF2 did 1 iteration, he can easy guess many passwords, but if PBKDF2 did a 10000 iterations, then the attacker would have to do 10000 iterations for every password he guesses, which is computatinally expensive and time taking. 
    )
    key = kdf.derive(password.encode())
    return key

def encrypt_aes(data, password):
    salt = os.urandom(16)       # can be any no. of bytes. eg: 8. It just ensures that two identical passwords produce different key, and the probabilty of collision is very unlikely (higher no.s make it more unlikely), 16 byte salt has a probablity of 1/2^128 for two keys ( derived from same password but different key) to match.
    IV = os.urandom(16)         # CBC chains in blocks of 16 bytes, hence IV needs to be 16 bytes so that it can be XORed wih 1st block.
    key = derive_key(password,salt)    
    padder = padding.PKCS7(128).padder()
    padded_data = padder.update(data) + padder.finalize()
    cipher = Cipher(algorithms.AES(key), modes.CBC(IV))
    encryptor = cipher.encryptor()
    cipher_text = encryptor.update(padded_data) + encryptor.finalize()  # .update() does all the encryption. it can be used multiple times ( streaming) and at the end .finalize() is called to indicate the end of stream.
    return salt + IV + cipher_text

def decrypt_aes(cipher_text, password):
    salt = cipher_text[:16]
    IV = cipher_text[16:32]
    text = cipher_text[32:]
    key = derive_key(password, salt)
    cipher = Cipher(algorithms.AES(key), modes.CBC(IV))
    decryptor = cipher.decryptor()
    data = decryptor.update(text) + decryptor.finalize()
    unpadder = padding.PKCS7(128).unpadder()             # We can instead store the extra padding adding and slice it off from the decrypted text. Padder is better because it doesn't require extra metadata. It stores the number of padding in the padding itself. For example, the file requires 5 padding, the padder adds "0x05 0x05 0x05 0x05 0x05" at the end. So the unpadder needs to just check the last digit and slice off that many number of padding (5 in this case). It also helps detect tampering in some cases when the attacker modifies the encrypted file near the end oof file. Suppose the padding becomes "0x05 0x05 91 0x05 0x05", the unpadder will identify it and report a value error. 
    unpadded_data = unpadder.update(data) + unpadder.finalize()
    return unpadded_data

def encrypt_rsa(data, public_key):
    aes_key = os.urandom(32)
    IV = os.urandom(16)
    cipher = Cipher(algorithms.AES(aes_key), modes.CBC(IV))
    encryptor = cipher.encryptor()
    padder = padding.PKCS7(128).padder()
    padded_data = padder.update(data) + padder.finalize()
    encrypted_data = encryptor.update(padded_data) + encryptor.finalize()

    encrypt_aes_key = public_key.encrypt(
        aes_key,
        rsa_padding.OAEP(
            mgf = rsa_padding.MGF1(algorithm=hashes.SHA256()),   # for generating the random no from different seeds and concatenating until we have a mask of required length.
            algorithm=hashes.SHA256(),    # For blending the randomness and aes key. aes_key + random.no --> hash it ---> so now even same aes_key would look different after hashing it.
            label = None  # Just an extra verifier while decrypting. The encryption label and decryption label must match for decryption to succeed, mostly it is not used adn set to None.
        )
    )
    return encrypt_aes_key+IV+encrypted_data
def decrypt_rsa(data, private_key):
    aes_key = data[:256]
    try:
        aes_key = private_key.decrypt(
            aes_key,
            rsa_padding.OAEP(
                mgf = rsa_padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label = None
            )
        )
    except ValueError:
        print("Warning: The file has been tampered.\n The AES key is damaged and the file content cannot be recovered.")
        sys.exit()
    IV = data[256:272]
    data = data[272:]
    cipher = Cipher(algorithms.AES(aes_key),modes.CBC(IV))
    decryptor = cipher.decryptor()
    decrypted_data = decryptor.update(data) + decryptor.finalize()
    unpadder = padding.PKCS7(128).unpadder()
    unpadded_data = unpadder.update(decrypted_data) + unpadder.finalize()
    return unpadded_data


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("action")
    parser.add_argument("filename")
    parser.add_argument("--shift", type = int)
    parser.add_argument("--verify", action = "store_true")
    args = parser.parse_args()

    if(args.action == "encrypt"):
        text = ""
        with open(args.filename, "r") as f:
            text = f.read()

        if(args.action == "encrypt"):
            if args.verify:
                hash = hashlib.sha256(text.encode()).hexdigest()
                new_text = hash + "\n" + caesar(text,args.shift)
            else:
                new_text = caesar(text, args.shift)
            with open(f'{args.filename}.enc', "w") as f:
                f.write("[CAE1]"+new_text)
            print("Message encrypted succesfully")

    elif(args.action == "decrypt"):
        text = ""
        if(args.filename[-4:] != ".enc"):
            print("Error: The file is not encrypted.")
            sys.exit()
        with open(args.filename, "r") as f:
            text = f.read()
        if args.verify:
            new_text = text[text.find("\n")+1:]          # Remove [CAE1] and hash
        else:
            new_text = text[6:]                          # Remove [CAE1]
        new_text = caesar(new_text, -args.shift)
        filename = args.filename[:-4]
        with open(filename, "w") as f:
            f.write(new_text)
        print("The encryption has been decrypted succesfully")
        if args.verify:
            verify(new_text, text[6:text.find("\n")])
    
    elif(args.action == "aes-encrypt"):
        password = input("Create Password: ")
        check = input("Confirm your password: ")
        if(check != password):
            print("The passwords don't match. Please try again.")
        else:
            text = b""
            with open(args.filename, "rb") as fb:
                text = fb.read()
            encrypted_data = encrypt_aes(text, password)
            if args.verify:
                hash = hashlib.sha256(text).hexdigest()         # hexdigest() converts the raw bytes(32 bytes) into hexdigits. Each byte becomes two hex digits. Now this is converted into a string ( 1 byte per character) and hence each digit (string) requires 1 byte.
                encrypted_data = hash.encode() + encrypted_data
            with open(args.filename + ".enc", "wb") as fb:
                fb.write(encrypted_data)
            print("The file has been encrypted successfully")
    elif(args.action == "aes-decrypt"):
        if(args.filename[-4:] != ".enc"):
            print("Error: The file is not encrypted")
        else:
            with open(args.filename, "rb") as fb:
                cipher_text = fb.read()
            if args.verify:
                try: 
                    hash = cipher_text[:64].decode()
                    cipher_text = cipher_text[64:]
                except UnicodeDecodeError:
                    print("Warning: The file has been tampered.")
                    exit()
            password = input("Enter the password: ")
            try:
                decrypted_data = decrypt_aes(cipher_text, password)
            except ValueError:
                print("Warning: Something went wrong. Possbile issues:\n1) Incorrect password.\n2)If you have added a '--verify' parameter, the encryption might not have included a hash, consider removing the '--verify' parameter.\n3)If you have not added a '--verify' parameter, the encryption might have included a hash, consider adding a '--verify' parameter.\n4)The file has been tampered.")
                sys.exit()
            if args.verify:
                computed_hash = hashlib.sha256(decrypted_data).hexdigest()
                if not (computed_hash==hash):
                    print("Warning: Something went wrong.\n1) If the text is gibberish, then most likely the password entered is wrong or the file has been rigourously tampered.\n2)If the text looks normal, then most likely the file has been tampered.")
                else:
                    print("The file is not tampered.")
            with open(args.filename[:-4], "wb") as fb:
                fb.write(decrypted_data)
            print("The file has been decrypted successfully.")

    elif(args.action == "keygen"):
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048
        )
        public_key = private_key.public_key()

        with open("private.pem", "wb") as f:
            f.write(private_key.private_bytes(          # .private_bytes converts the key object into bbytes that can be written into a file. 
                encoding= serialization.Encoding.PEM,       # We are converting the key from raw binary to base64. This is done to make transmission (copy-pasting) safe, because raw binary files can be misinterpreted by many systems like Email,text editors, terminals,etc. 
                format = serialization.PrivateFormat.PKCS8,       # PKCS8 is a standard that defines the structure of how the private key is arranged inside the file. 
                encryption_algorithm=serialization.NoEncryption()    # We are not encrypting the file that stores the private key
            ))

        with open("public.pem", "wb") as f:
            f.write(public_key.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo        # Using standard structure for storing public key.
            ))
    elif(args.action == "rsa-encrypt"):
        text = b""
        try:
            with open("public.pem", "rb") as f:
                public_key = serialization.load_pem_public_key(f.read())
        except FileNotFoundError:
            print("Error: Key not found. Generate a private and public key before encrypting.")
            sys.exit()
        with open(args.filename, "rb") as fb:
            text = fb.read()
        encrypted_data = encrypt_rsa(text, public_key)
        if args.verify:
            hash = hashlib.sha256(text).hexdigest()
            with open(args.filename +".enc", "wb") as fb:
                fb.write(hash.encode() + encrypted_data)
        else:
            with open(args.filename+".enc", "wb") as fb:
                fb.write(encrypted_data)
        print("Your file has been encrypted successfully")
    elif(args.action == "rsa-decrypt"):
        if args.filename[-4:] == ".enc":
            try:
                with open("private.pem", "rb") as f:
                    private_key = serialization.load_pem_private_key(
                        f.read(),
                        password=None
                    )
            except FileNotFoundError:
                print("Error: Key not found. A private key is required for decryption.")
                sys.exit()
            text = b""
            with open(args.filename, "rb") as fb:
                text = fb.read()
            if args.verify:
                hash = text[:64].decode()
                text = text[64:]
                decrypted_data = decrypt_rsa(text, private_key)
                with open(args.filename[:-4], "wb") as fb:
                    fb.write(decrypted_data)
                computed_hash = hashlib.sha256(decrypted_data).hexdigest()
                if(not (computed_hash==hash)):
                    print("Warning: The file has been tampered.")
                else:
                    print("The file is not tampered\nThe file has been decrypted successfully.")
            else:
                decrypted_data = decrypt_rsa(text, private_key)
                with open(args.filename[:-4], "wb") as fb:
                    fb.write(decrypted_data)
                print("Your file has been decrypted successfully.")
        else:
            print("Error: The file is not encrypted.")
            sys.exit()

    elif(args.action == "crack"):
        with open(args.filename, "rb") as f:
            text = f.read()
        if text.decode()[:6] == "[CAE1]":
            text = text.decode()
            text = text[6:]
            crack(text)
            print("The encryption has been cracked.")
        else:
            print("AES or RSA encryption cannot be cracked.")
    else: 
        print("Error: Action entered is not valid.")